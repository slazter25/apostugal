﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace Apostugal
{
    public partial class editar_produto : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null)
            {
                Response.Redirect("login.aspx");
            }

            if (!Page.IsPostBack)
            {
                string query = "select * from produtos where cod_produto=" + Request.QueryString["cod_produto"];

                SqlConnection myConn = new SqlConnection(ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);
                SqlCommand myCommand = new SqlCommand(query, myConn);

                myConn.Open();
                SqlDataReader reader = myCommand.ExecuteReader();

                while (reader.Read())
                {
                    tb_nome.Text = reader["designacao"].ToString();
                    string pvp = reader["pvp"].ToString();

                    string[] preco = pvp.Split('.');

                    tb_euros.Text = preco[0];
                    tb_cents.Text = preco[1];


                    tb_stock.Text = reader["stock"].ToString();
                    
                }

                myConn.Close();
            }
        }

        protected void btn_submeter_Click(object sender, EventArgs e)
        {
            SqlConnection myConn = new SqlConnection(ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);

            myConn.Open();

            string query = "UPDATE produtos SET ";
            query += "designacao = '" + tb_nome.Text + "', ";
            query += "pvp = '" + tb_euros.Text +"." +tb_cents.Text + "', ";
            query += "stock = '" + tb_stock.Text + "'";
            query += "WHERE cod_produto = " + Request.QueryString["cod_produto"];

            SqlCommand myCommand = new SqlCommand(query, myConn);
            myCommand.ExecuteNonQuery();

            myConn.Close();

            Response.Redirect("gestaodeprodutos.aspx");
        }
    }
}