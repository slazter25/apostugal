﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Apostugal
{
    public partial class inicio : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["cliente"]==null)
            {
                Response.Redirect("login.aspx");
            }
            string query = "SELECT jogos.jornada, jogos.id_jogo, equipas.nome as 'Equipa Casa', equipas_1.nome AS 'Equipa Visitante'  FROM equipas INNER JOIN  jogos ON equipas.id_equipa = jogos.id_equipa_casa INNER JOIN equipas AS equipas_1 ON jogos.id_equipa_fora = equipas_1.id_equipa Where jogos.jornada =";

            
            if (!Page.IsPostBack)
            {

                Session["jornada"] = 1;

                SqlDataSource1.SelectCommand = query + Session["jornada"];
                Repeater1.DataBind();
            }
           // else
           // {
               
                //    Session["jornada"] = Convert.ToInt32(Session["jornada"]) + 1;
                //    SqlDataSource1.SelectCommand = query + Session["jornada"];
                //    Repeater1.DataBind();
                
                //if(Convert.ToInt32(Session["jornada"]) == 35)
                //{
                //    liga.InnerText = "A LIGA TERMINOU";
                //    liga.Style.Add("text-align", "center"); 
                //    btn_saltar.Visible = false;
                //    btn_reiniciar.Visible = true;
                //    Repeater1.Visible = false;
                    
                //}
           // }
          
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName.Equals("btn_apostar"))

            {
                Session["id_jogo"] = (Convert.ToInt32(((LinkButton)e.Item.FindControl("btn_apostar")).CommandArgument.ToString()));
                Response.Redirect("apostar.aspx?jogo=" + (Convert.ToInt32(((LinkButton)e.Item.FindControl("btn_apostar")).CommandArgument.ToString()) ));
            }
        }

        protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                DataRowView dr = (DataRowView)e.Item.DataItem;
                ((Label)e.Item.FindControl("lbl_jornada")).Text = dr["jornada"].ToString();


                ((Label)e.Item.FindControl("lbl_jogo")).Text = dr["id_jogo"].ToString();


                ((Label)e.Item.FindControl("lbl_casa")).Text = dr["Equipa Casa"].ToString();


                ((Label)e.Item.FindControl("lbl_fora")).Text = dr["Equipa Visitante"].ToString();


                ((LinkButton)e.Item.FindControl("btn_apostar")).CommandArgument = dr["id_jogo"].ToString();




            }
        }

        protected void btn_saltar_Click(object sender, EventArgs e)
        {

            string apostas = $"Select count * from apostas a, apostas_utilizador au where au.id_utilzador ={Session["id"]} and a.id_aposta = au.id_aposta";

            //if (Convert.ToInt32(apostas) != 0)
            //{
            //    Response.Redirect("total_apostas.aspx");
            //}
            //else
            //{
                string query = "SELECT jogos.jornada, jogos.id_jogo, equipas.nome as 'Equipa Casa', equipas_1.nome AS 'Equipa Visitante'  FROM equipas INNER JOIN  jogos ON equipas.id_equipa = jogos.id_equipa_casa INNER JOIN equipas AS equipas_1 ON jogos.id_equipa_fora = equipas_1.id_equipa Where jogos.jornada =";

                Session["jornada"] = Convert.ToInt32(Session["jornada"]) + 1;
                SqlDataSource1.SelectCommand = query + Session["jornada"];
                Repeater1.DataBind();

                if (Convert.ToInt32(Session["jornada"]) == 35)
                {
                    liga.InnerText = "A LIGA TERMINOU";
                    liga.Style.Add("text-align", "center");
                    btn_saltar.Visible = false;
                    btn_reiniciar.Visible = true;
                    Repeater1.Visible = false;

                }
            //}
        }

        protected void btn_reiniciar_Click(object sender, EventArgs e)
        {
            Response.Redirect("inicio.aspx");
            //Session["jornada"]= 0;
            //Repeater1.Visible = true;
            //Repeater1.DataBind();
            //btn_saltar.Visible = true;
            //btn_reiniciar.Visible = false;
            //liga.Visible = true;
        }
    }
}