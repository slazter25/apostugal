﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Apostugal
{
    public partial class inicio : System.Web.UI.Page
    {
        SqlConnection myConn;
        SqlConnection myConn2;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["cliente"] == null)
            {
                Response.Redirect("login.aspx");
            }
            string query = "SELECT jogos.jornada, jogos.id_jogo, equipas.nome as 'Equipa Casa', equipas_1.nome AS 'Equipa Visitante'  FROM equipas INNER JOIN  jogos ON equipas.id_equipa = jogos.id_equipa_casa INNER JOIN equipas AS equipas_1 ON jogos.id_equipa_fora = equipas_1.id_equipa Where jogos.jornada =";

            string resultados_apostas = $"SELECT distinct aposta_utilizador.id_aposta_util, aposta_utilizador.valor, apostas.descricao, Concat(stats_jogo.golos_casa, ' - ', stats_jogo.golos_fora) as Resultado, stats_jogo.total_cantos, stats_jogo.total_amarelos, stats_jogo.total_vermelhos, Concat(equipas.nome, ' - ', equipas_1.nome) as Jogo, aposta_utilizador.id_aposta, aposta_utilizador.id_utilizador, Round(aposta_utilizador.valor*apostas.odd,2,0) as 'Ganhos Possiveis' FROM aposta_utilizador INNER JOIN apostas INNER JOIN equipas INNER JOIN jogos ON equipas.id_equipa = jogos.id_equipa_casa INNER JOIN equipas AS equipas_1 ON jogos.id_equipa_fora = equipas_1.id_equipa ON apostas.id_jogo = jogos.id_jogo ON aposta_utilizador.id_aposta = apostas.id_aposta INNER JOIN stats_jogo ON jogos.id_jogo = stats_jogo.id_jogo where aposta_utilizador.id_utilizador = {Session["id"]} and aposta_utilizador.ativa = 1";


            if (!Page.IsPostBack)
            {

                if (Session["atual"] == null)
                {
                    Session["jornada"] = 1;
                    Session["atual"] = Session["jornada"];
                }
                else
                {

                    Session["jornada"] = Session["atual"];
                }


                SqlDataSource1.SelectCommand = query + Session["jornada"];
                SqlDataSource2.SelectCommand = resultados_apostas;
                Repeater1.DataBind();
                Repeater2.DataBind();
            }
            // else
            // {

            //    Session["jornada"] = Convert.ToInt32(Session["jornada"]) + 1;
            //    SqlDataSource1.SelectCommand = query + Session["jornada"];
            //    Repeater1.DataBind();

            //if(Convert.ToInt32(Session["jornada"]) == 35)
            //{
            //    liga.InnerText = "A LIGA TERMINOU";
            //    liga.Style.Add("text-align", "center"); 
            //    btn_saltar.Visible = false;
            //    btn_reiniciar.Visible = true;
            //    Repeater1.Visible = false;

            //}
            // }

        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName.Equals("btn_apostar"))

            {
                Session["id_jogo"] = (Convert.ToInt32(((LinkButton)e.Item.FindControl("btn_apostar")).CommandArgument.ToString()));
                Response.Redirect("apostar.aspx?jogo=" + (Convert.ToInt32(((LinkButton)e.Item.FindControl("btn_apostar")).CommandArgument.ToString())));
            }
        }

        protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                DataRowView dr = (DataRowView)e.Item.DataItem;
                ((Label)e.Item.FindControl("lbl_jornada")).Text = dr["jornada"].ToString();


                ((Label)e.Item.FindControl("lbl_jogo")).Text = dr["id_jogo"].ToString();


                ((Label)e.Item.FindControl("lbl_casa")).Text = dr["Equipa Casa"].ToString();


                ((Label)e.Item.FindControl("lbl_fora")).Text = dr["Equipa Visitante"].ToString();


                ((LinkButton)e.Item.FindControl("btn_apostar")).CommandArgument = dr["id_jogo"].ToString();




            }
        }

        protected void btn_saltar_Click(object sender, EventArgs e)
        {

            string query = "SELECT jogos.jornada, jogos.id_jogo, equipas.nome as 'Equipa Casa', equipas_1.nome AS 'Equipa Visitante'  FROM equipas INNER JOIN  jogos ON equipas.id_equipa = jogos.id_equipa_casa INNER JOIN equipas AS equipas_1 ON jogos.id_equipa_fora = equipas_1.id_equipa Where jogos.jornada =";

            gerarResultados();

            temApostas();



            Session["atual"] = Convert.ToInt32(Session["jornada"]) + 1;


            if (Session["atual"] == null)
            {
                Session["jornada"] = 1;
            }
            else
            {

                Session["jornada"] = Session["atual"];
            }

            SqlDataSource1.SelectCommand = query + Session["atual"].ToString();


            if (Convert.ToInt32(Session["jornada"]) == 35)
            {
                liga.InnerText = "A LIGA TERMINOU";
                liga.Style.Add("text-align", "center");
                btn_saltar.Visible = false;
                btn_reiniciar.Visible = true;
                Repeater1.Visible = false;

            }


        }

        protected void btn_reiniciar_Click(object sender, EventArgs e)
        {
            Session["atual"] = 1;
            Response.Redirect("inicio.aspx");
            //Session["jornada"]= 0;
            //Repeater1.Visible = true;
            //Repeater1.DataBind();
            //btn_saltar.Visible = true;
            //btn_reiniciar.Visible = false;
            //liga.Visible = true;
        }



        protected void Repeater2_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                DataRowView dr = (DataRowView)e.Item.DataItem;

                ((Label)e.Item.FindControl("lbl_id_jogo_aposta")).Text = dr["id_aposta_util"].ToString();

                ((Label)e.Item.FindControl("lbl_valor_aposta")).Text = dr["valor"].ToString();


                ((Label)e.Item.FindControl("lbl_descricao")).Text = dr["descricao"].ToString();


                ((Label)e.Item.FindControl("lbl_jogo_aposta")).Text = dr["Jogo"].ToString();

                ((Label)e.Item.FindControl("lbl_resultado")).Text = dr["Resultado"].ToString();

                ((Label)e.Item.FindControl("lbl_total_cantos")).Text = dr["total_cantos"].ToString();

                ((Label)e.Item.FindControl("lbl_total_ca")).Text = dr["total_amarelos"].ToString();

                ((Label)e.Item.FindControl("lbl_total_cv")).Text = dr["total_vermelhos"].ToString();

                ((Label)e.Item.FindControl("lbl_ganhos")).Text = Math.Round(Convert.ToDouble(dr["Ganhos Possiveis"]), 2).ToString();

            }
        }

        protected void btn_ok_Click(object sender, EventArgs e)
        {
            string query = "SELECT jogos.jornada, jogos.id_jogo, equipas.nome as 'Equipa Casa', equipas_1.nome AS 'Equipa Visitante'  FROM equipas INNER JOIN  jogos ON equipas.id_equipa = jogos.id_equipa_casa INNER JOIN equipas AS equipas_1 ON jogos.id_equipa_fora = equipas_1.id_equipa Where jogos.jornada =";



            try
            {

                myConn = new SqlConnection(ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);

                SqlCommand myCommand = new SqlCommand();

                myCommand.Parameters.AddWithValue("@id", Session["id"].ToString());





                myCommand.CommandType = CommandType.StoredProcedure;


                myCommand.CommandText = "apostaTerminada";

                SqlParameter valor = new SqlParameter();
                valor.ParameterName = "@retorno";

                valor.Direction = ParameterDirection.Output;
                valor.SqlDbType = SqlDbType.Int;
                valor.Size = 1;

                myCommand.Parameters.Add(valor);
                myCommand.Connection = myConn;


                myConn.Open();

                myCommand.ExecuteNonQuery();




                int resposta = Convert.ToInt32(myCommand.Parameters["@retorno"].Value);

                if (resposta == 1)
                {
                    btn_saltar.Visible = true;
                    Repeater1.Visible = true;
                    Repeater2.Visible = false;

                    btn_ok.Visible = false;

                    Repeater1.DataBind();
                    Response.Redirect("inicio.aspx");

                }
                else
                {
                    btn_saltar.Visible = true;
                    Repeater1.Visible = true;
                    Repeater2.Visible = false;

                    btn_ok.Visible = false;

                    Repeater1.DataBind();
                    Response.Redirect("inicio.aspx");
                }
            }

            catch (Exception ex)

            {
                Response.Write(ex.Message);
            }

            finally
            {
                myConn.Close();
            }




            //update ativa para 0 
        }
        /// <summary>
        /// Gera resultados através de random positions em arrays
        /// </summary>
        protected void gerarResultados()
        {
            string query = "SELECT jogos.jornada, jogos.id_jogo, equipas.nome as 'Equipa Casa', equipas_1.nome AS 'Equipa Visitante'  FROM equipas INNER JOIN  jogos ON equipas.id_equipa = jogos.id_equipa_casa INNER JOIN equipas AS equipas_1 ON jogos.id_equipa_fora = equipas_1.id_equipa Where jogos.jornada =";

            int[] resultados_fortes = new int[75] { 4, 1, 3, 1, 0, 3, 2, 2, 2, 3, 3, 3, 0, 2, 1, 4, 2, 2, 2, 3, 4, 3, 5, 2, 2, 3, 4, 3, 2, 3, 2, 3, 3, 5, 2, 2, 3, 1, 3, 1, 2, 3, 0, 3, 2, 5, 4, 5, 2, 1, 2, 3, 2, 1, 4, 5, 2, 3, 3, 2, 2, 1, 5, 5, 3, 2, 5, 4, 2, 3, 2, 1, 3, 2, 2 };

            int[] resultados_medios = new int[75] { 0, 1, 1, 1, 0, 0, 2, 2, 2, 3, 0, 3, 0, 2, 1, 0, 2, 0, 2, 3, 1, 2, 1, 2, 1, 3, 1, 3, 2, 2, 1, 3, 3, 0, 2, 1, 1, 1, 0, 1, 0, 3, 0, 3, 0, 1, 2, 0, 2, 1, 1, 1, 1, 2, 0, 2, 1, 1, 2, 3, 2, 1, 2, 2, 1, 0, 2, 1, 0, 0, 1, 1, 2, 0, 0 };

            int[] resultados_fracos = new int[75] { 0, 1, 1, 1, 0, 0, 2, 0, 2, 3, 0, 1, 0, 2, 1, 0, 2, 1, 2, 0, 2, 1, 0, 2, 1, 3, 0, 3, 2, 2, 2, 0, 0, 0, 2, 1, 1, 1, 0, 1, 0, 1, 0, 1, 2, 1, 2, 0, 2, 0, 2, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 1, 1, 1, 0, 2, 0, 2, 1, 0 };

            int[] cantos_total = new int[75] { 7, 9, 13, 6, 5, 7, 8, 9, 12, 13, 10, 21, 10, 7, 8, 5, 6, 7, 9, 10, 12, 5, 7, 15, 13, 13, 10, 13, 12, 12, 9, 7, 3, 10, 12, 11, 11, 11, 10, 8, 10, 11, 7, 6, 7, 8, 6, 11, 7, 10, 23, 7, 6, 12, 5, 7, 13, 9, 7, 7, 12, 11, 7, 12, 7, 6, 21, 11, 5, 7, 4, 12, 12, 10, 7 };

            int[] ca_total = new int[75] { 5, 4, 5, 6, 5, 3, 2, 5, 2, 3, 8, 9, 2, 3, 8, 2, 6, 7, 2, 1, 8, 5, 7, 6, 3, 3, 9, 6, 7, 10, 4, 7, 3, 7, 8, 3, 5, 5, 4, 6, 5, 8, 7, 6, 1, 8, 6, 1, 7, 7, 3, 7, 6, 12, 5, 7, 5, 9, 7, 7, 2, 1, 4, 8, 7, 6, 2, 5, 5, 7, 3, 7, 6, 8, 7 };

            int[] cv_total = new int[75] { 0, 0, 0, 1, 0, 0, 2, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 2, 0, 1, 0, 0, 0, 2, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 2, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 2, 0, 2, 3, 0 };



            myConn = new SqlConnection(ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);
            myConn2 = new SqlConnection(ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);

            myConn.Open();

            string query2 = $"SELECT jogos.id_jogo as 'id_jogo', equipas_1.nome, equipas_1.forca_casa, equipas.nome AS Expr1, equipas.forca_fora FROM equipas INNER JOIN equipas AS equipas_1 INNER JOIN jogos ON equipas_1.id_equipa = jogos.id_equipa_casa ON equipas.id_equipa = jogos.id_equipa_fora where jogos.jornada = {Session["atual"].ToString()}";

            int h = Convert.ToInt32(Session["atual"]);



            SqlCommand myCommand = new SqlCommand(query2, myConn);
            Random rand_forte = new Random();
            Random rand_medio = new Random();
            Random rand_fraco = new Random();
            Random rand_forte_fora = new Random();
            Random rand_medio_fora = new Random();
            Random rand_fraco_fora = new Random();
            Random rand_cantos = new Random();
            Random rand_ca = new Random();
            Random rand_cv = new Random();

            SqlDataReader reader = myCommand.ExecuteReader();
            while (reader.Read())
            {
                int id_jogo = Convert.ToInt32(reader["id_jogo"]);
                int forca_casa = Convert.ToInt32(reader["forca_casa"]);
                int forca_fora = Convert.ToInt32(reader["forca_fora"]);
                int golos_casa = 9;
                int golos_fora = 9;

                if (forca_casa > 80)
                {


                    int golos_fortes_pos = rand_forte.Next(resultados_fortes.Length);

                    golos_casa = resultados_fortes[golos_fortes_pos];

                    lbl_golos_casa_final.Text = golos_casa.ToString();
                }
                if (forca_casa < 80 && forca_casa > 66)
                {


                    int golos_medios_pos = rand_medio.Next(resultados_medios.Length);
                    golos_casa = resultados_medios[golos_medios_pos];

                    lbl_golos_casa_final.Text = golos_casa.ToString();
                }
                if (forca_casa <= 66)
                {


                    int golos_fracos_pos = rand_fraco.Next(resultados_fracos.Length);
                    golos_casa = resultados_fracos[golos_fracos_pos];

                    lbl_golos_casa_final.Text = golos_casa.ToString();
                }
                if (forca_fora > 80)
                {


                    int golos_fortes_fora_pos = rand_forte_fora.Next(resultados_fortes.Length);
                    golos_fora = resultados_fortes[golos_fortes_fora_pos];

                    lbl_golos_fora_final.Text = golos_fora.ToString();
                }
                if (forca_fora < 80 && forca_fora > 61)
                {
                    int golos_medios_fora_pos = rand_medio_fora.Next(resultados_medios.Length);
                    golos_fora = resultados_medios[golos_medios_fora_pos];

                    lbl_golos_fora_final.Text = golos_fora.ToString();
                }
                if (forca_fora <= 61)
                {


                    int golos_fracos_fora_pos = rand_fraco_fora.Next(resultados_fracos.Length);
                    golos_fora = resultados_fracos[golos_fracos_fora_pos];

                    lbl_golos_fora_final.Text = golos_fora.ToString();
                }
                //Cantos


                int cantos_pos = rand_cantos.Next(cantos_total.Length);
                int cantos = cantos_total[cantos_pos];

                lbl_total_cantos_final.Text = cantos.ToString();

                //Cartões amarelos


                int ca_pos = rand_ca.Next(ca_total.Length);
                int ca = ca_total[ca_pos];

                lbl_total_ca_final.Text = ca.ToString();

                //Cartões vermelhos



                int cv_pos = rand_cv.Next(cv_total.Length);
                int cv = cv_total[cv_pos];

                lbl_total_cv_final.Text = cv.ToString();


                SqlCommand myCommand2 = new SqlCommand();
                myConn2.Open();

                myCommand2.Parameters.AddWithValue("@id_jogo", id_jogo);
                myCommand2.Parameters.AddWithValue("@golos_casa", golos_casa);
                myCommand2.Parameters.AddWithValue("@golos_fora", golos_fora);
                myCommand2.Parameters.AddWithValue("@cantos", cantos);
                myCommand2.Parameters.AddWithValue("@ca", ca);
                myCommand2.Parameters.AddWithValue("@cv", cv);

                myCommand2.CommandType = CommandType.StoredProcedure;

                myCommand2.CommandText = "getResultados";

                SqlParameter valor = new SqlParameter();

                valor.ParameterName = "@retorno";

                valor.Direction = ParameterDirection.Output;
                valor.SqlDbType = SqlDbType.Int;

                valor.Size = 1;

                myCommand2.Parameters.Add(valor);
                myCommand2.Connection = myConn2;





                myCommand2.ExecuteNonQuery();


                int resposta = Convert.ToInt32(myCommand2.Parameters["@retorno"].Value);

                if (resposta == 1)
                {
                    //Response.Write("Jogos inseridos");


                    //Session["atual"] = Session["jornada"];
                    //SqlDataSource1.SelectCommand = query + Session["jornada"];

                    Repeater1.DataBind();

                    Repeater1.Visible = true;
                    btn_saltar.Visible = true;



                }

                myConn2.Close();
            }
            myConn.Close();
        }

     
        /// <summary>
        /// Verifica se o utilizador tem apostas para esta jornada
        /// </summary>
        protected void temApostas()
        {
            try
            {
                myConn = new SqlConnection(ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);

                SqlCommand myCommand2 = new SqlCommand();

                myCommand2.Parameters.AddWithValue("@id", Session["id"].ToString());

                myCommand2.CommandType = CommandType.StoredProcedure;


                myCommand2.CommandText = "temApostas";

                SqlParameter valor1 = new SqlParameter();
                valor1.ParameterName = "@retorno";

                valor1.Direction = ParameterDirection.Output;
                valor1.SqlDbType = SqlDbType.Int;
                valor1.Size = 1;

                myCommand2.Parameters.Add(valor1);
                myCommand2.Connection = myConn;


                myConn.Open();

                myCommand2.ExecuteNonQuery();




                int resposta1 = Convert.ToInt32(myCommand2.Parameters["@retorno"].Value);

                if (resposta1 == 1)
                {
                    Repeater1.Visible = false;
                    Repeater2.Visible = true;
                    btn_saltar.Visible = false;
                    btn_ok.Visible = true;


                }



            }

            catch (Exception ex)

            {
                Response.Write(ex.Message);
            }

            finally
            {
                myConn.Close();
            }
        }
    }
}






