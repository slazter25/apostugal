﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Apostugal
{
    public partial class loja : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["cliente"]==null)
            {
                Response.Redirect("login.aspx");
            }
            if (!Page.IsPostBack)
            {
                using (SqlConnection myConnection = new SqlConnection(SqlDataSource1.ConnectionString))
                {
                    myConnection.Open();
                    string query = null;
                    

                    query = "SELECT SUM(quantidade) as quant FROM carrinho where id_utilizador =" + Session["id"] + "";
                  

                    using (SqlCommand myCommand = new SqlCommand(query, myConnection))
                    {
                        using (SqlDataReader reader = myCommand.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                if (reader["quant"].ToString() != "")
                                {
                                    lbl_quantidade.Text = "Tem " + reader["quant"].ToString() + " itens no carrinho";
                                }
                                else
                                {
                                    lbl_quantidade.Text = "Tem 0 itens no carrinho";
                                }
                                   
                            }
                        }
                    }
                    myConnection.Close();

                }



            }
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            SqlConnection myConn = new SqlConnection(SqlDataSource1.ConnectionString);

            myConn.Open();

            if (e.CommandName.Equals("btn_ok"))
            {
                string query = "insert into carrinho (cod_produto, id_utilizador, quantidade, comprado, data_compra, total) values (" + ((Label)e.Item.FindControl("lbl_id")).Text + ", " + Session["id"].ToString()+ ", " +((DropDownList)e.Item.FindControl("ddl_quantidade")).SelectedValue + ", 'false', getDate(),"+  ((DropDownList)e.Item.FindControl("ddl_quantidade")).SelectedValue  + "* ( Select pvp from produtos where cod_produto = '" + ((Label)e.Item.FindControl("lbl_id")).Text +"'))";

                SqlCommand myCommand = new SqlCommand(query, myConn);

                myCommand.ExecuteNonQuery();

            }

            myConn.Close();

            Response.Redirect("loja.aspx");
        }

        protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                DataRowView dr = (DataRowView)e.Item.DataItem;

                ((Label)e.Item.FindControl("lbl_id")).Text = dr["cod_produto"].ToString();

                ((Label)e.Item.FindControl("lbl_produto")).Text = dr["designacao"].ToString();

                ((Label)e.Item.FindControl("lbl_pvp")).Text = dr["pvp"].ToString();
                
                ((Label)e.Item.FindControl("lbl_stock")).Text = dr["stock"].ToString();

                ((LinkButton)e.Item.FindControl("btn_ok")).CommandArgument = dr["cod_produto"].ToString();

            }
        }

        protected void btn_pesquisar_Click(object sender, EventArgs e)
        {
            {
                SqlDataSource1.SelectCommand = "select * from produtos where designacao like '%" + tb_pesquisar.Text + "%'";

            }

        }

        protected void ddl_ordenar_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddl_ordenar.SelectedValue == "1")
            {
                SqlDataSource1.SelectCommand = "select * from produtos order by pvp asc";
            }

            else if (ddl_ordenar.SelectedValue == "2")
            {
                SqlDataSource1.SelectCommand = "select * from produtos order by pvp desc";
            }

            else if (ddl_ordenar.SelectedValue == "3")
            {
                SqlDataSource1.SelectCommand = "select * from produtos order by designacao asc";
            }

            else
            {
                SqlDataSource1.SelectCommand = "select * from produtos order by designacao desc";
            }
        }
    }
}