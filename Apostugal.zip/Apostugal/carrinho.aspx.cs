﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Apostugal
{
    public partial class carrinho : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["cliente"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            SqlDataSource1.SelectCommand = "Select c.cod_produto, p.designacao, p.pvp, c.quantidade from carrinho c, produtos p where c.cod_produto = p.cod_produto AND c.id_utilizador ='" + Session["id"]+ "'";
            if (!Page.IsPostBack)
            {
                using (SqlConnection myConn = new SqlConnection(SqlDataSource1.ConnectionString))
                {
                    myConn.Open();


                    string query = null;
                    string total = null;

                    total = "Select Sum(total) as total FROM carrinho where id_utilizador ='" + Session["id"] +"'";
                    query = "SELECT SUM(quantidade) as quant FROM carrinho where id_utilizador ='" + Session["id"] + "'";


                    using (SqlCommand myCommand = new SqlCommand(query, myConn))
                    {
                        using (SqlDataReader reader = myCommand.ExecuteReader())
                        {
                            while (reader.Read())
                            {

                                if (reader["quant"].ToString() != "")
                                {
                                    lbl_quantidade.Text = "Tem " + reader["quant"].ToString() + " itens no carrinho";
                                }
                                else
                                {
                                    lbl_quantidade.Text = "Tem 0 itens no carrinho";
                                }
                            }
                        }
                    }
                    using (SqlCommand myCommand = new SqlCommand(total, myConn))
                    {
                        using (SqlDataReader reader = myCommand.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                if (reader["total"].ToString() != "")
                                {
                                    lbl_total.Text = reader["total"].ToString();
                                }
                                else
                                {
                                    lbl_total.Text = "0";
                                }
                            }
                        }
                    }
                    myConn.Close();

                }
            }
        }
        protected void btn_comprar_Click(object sender, EventArgs e)
        {

        }

        protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                DataRowView dr = (DataRowView)e.Item.DataItem;

                ((Label)e.Item.FindControl("lbl_id")).Text = dr["cod_produto"].ToString();

                ((Label)e.Item.FindControl("lbl_produto")).Text = dr["designacao"].ToString();

                ((Label)e.Item.FindControl("lbl_pvp")).Text = dr["pvp"].ToString();

                ((Label)e.Item.FindControl("lbl_quantidade")).Text = dr["quantidade"].ToString();

                ((LinkButton)e.Item.FindControl("btn_remove")).CommandArgument = dr["cod_produto"].ToString();

            }
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            SqlConnection myConn = new SqlConnection(SqlDataSource1.ConnectionString);

            myConn.Open();

            if (e.CommandName.Equals("btn_remove"))
            {
                string query = "delete from carrinho where cod_produto ='" +((Label)e.Item.FindControl("lbl_id")).Text + "'";

                SqlCommand myCommand = new SqlCommand(query, myConn);

                myCommand.ExecuteNonQuery();

            }

            myConn.Close();

            Response.Redirect("carrinho.aspx");
        }
    }
}