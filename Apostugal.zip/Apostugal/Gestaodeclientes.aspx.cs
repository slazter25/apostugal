﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Security.Cryptography;

namespace Apostugal
{
    public partial class Gestaodeclientes : System.Web.UI.Page
    {
        

        public static string EncryptString(string Message)
        {
            string Passphrase = "apostas";
            byte[] Results;
            System.Text.UTF8Encoding UTF8 = new System.Text.UTF8Encoding();

            // Step 1. We hash the passphrase using MD5
            // We use the MD5 hash generator as the result is a 128 bit byte array
            // which is a valid length for the TripleDES encoder we use below

            MD5CryptoServiceProvider HashProvider = new MD5CryptoServiceProvider();
            byte[] TDESKey = HashProvider.ComputeHash(UTF8.GetBytes(Passphrase));

            // Step 2. Create a new TripleDESCryptoServiceProvider object
            TripleDESCryptoServiceProvider TDESAlgorithm = new TripleDESCryptoServiceProvider();

            // Step 3. Setup the encoder
            TDESAlgorithm.Key = TDESKey;
            TDESAlgorithm.Mode = CipherMode.ECB;
            TDESAlgorithm.Padding = PaddingMode.PKCS7;

            // Step 4. Convert the input string to a byte[]
            byte[] DataToEncrypt = UTF8.GetBytes(Message);

            // Step 5. Attempt to encrypt the string
            try
            {
                ICryptoTransform Encryptor = TDESAlgorithm.CreateEncryptor();
                Results = Encryptor.TransformFinalBlock(DataToEncrypt, 0, DataToEncrypt.Length);
            }
            finally
            {
                // Clear the TripleDes and Hashprovider services of any sensitive information
                TDESAlgorithm.Clear();
                HashProvider.Clear();
            }

            // Step 6. Return the encrypted string as a base64 encoded string

            string enc = Convert.ToBase64String(Results);
            enc = enc.Replace("+", "KKK");
            enc = enc.Replace("/", "JJJ");
            enc = enc.Replace("\\", "III");
            return enc;
        }


        public static string DecryptString(string Message)
        {
            string Passphrase = "apostas";
            byte[] Results;
            System.Text.UTF8Encoding UTF8 = new System.Text.UTF8Encoding();

            // Step 1. We hash the passphrase using MD5
            // We use the MD5 hash generator as the result is a 128 bit byte array
            // which is a valid length for the TripleDES encoder we use below

            MD5CryptoServiceProvider HashProvider = new MD5CryptoServiceProvider();
            byte[] TDESKey = HashProvider.ComputeHash(UTF8.GetBytes(Passphrase));

            // Step 2. Create a new TripleDESCryptoServiceProvider object
            TripleDESCryptoServiceProvider TDESAlgorithm = new TripleDESCryptoServiceProvider();

            // Step 3. Setup the decoder
            TDESAlgorithm.Key = TDESKey;
            TDESAlgorithm.Mode = CipherMode.ECB;
            TDESAlgorithm.Padding = PaddingMode.PKCS7;

            // Step 4. Convert the input string to a byte[]

            Message = Message.Replace("KKK", "+");
            Message = Message.Replace("JJJ", "/");
            Message = Message.Replace("III", "\\");


            byte[] DataToDecrypt = Convert.FromBase64String(Message);

            // Step 5. Attempt to decrypt the string
            try
            {
                ICryptoTransform Decryptor = TDESAlgorithm.CreateDecryptor();
                Results = Decryptor.TransformFinalBlock(DataToDecrypt, 0, DataToDecrypt.Length);
            }
            finally
            {
                // Clear the TripleDes and Hashprovider services of any sensitive information
                TDESAlgorithm.Clear();
                HashProvider.Clear();
            }

            // Step 6. Return the decrypted string in UTF8 format
            return UTF8.GetString(Results);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"]== null)
            {
                Response.Redirect("login.aspx");
            }
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
         

            if (e.CommandName.Equals("btn_ok"))
            {
                Response.Redirect("editar.aspx?id_utilizador=" + ((Label)e.Item.FindControl("lbl_cod")).Text);
            }

            SqlConnection myConn = new SqlConnection(ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);

            if (e.CommandName.Equals("btn_apaga"))
            {
              
                string query = "Delete from candidatos where id_utilizador=" + ((LinkButton)e.Item.FindControl("btn_apaga")).CommandArgument;
                SqlCommand myCommand = new SqlCommand(query, myConn);
                myCommand.ExecuteNonQuery();

            }



        }

        protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                DataRowView dr = (DataRowView)e.Item.DataItem;
                ((Label)e.Item.FindControl("lbl_cod")).Text = dr["id_utilizador"].ToString();


                ((Label)e.Item.FindControl("lbl_nome")).Text = dr["nome"].ToString();


                ((Label)e.Item.FindControl("lbl_morada")).Text = dr["morada"].ToString();


                ((Label)e.Item.FindControl("lbl_data_nasc")).Text = dr["data_nascimento"].ToString();

                ((Label)e.Item.FindControl("lbl_email")).Text = dr["email"].ToString();


                ((Label)e.Item.FindControl("lbl_user")).Text = dr["username"].ToString();

                ((Label)e.Item.FindControl("lbl_pw")).Text = dr["palavra_pass"].ToString();

                ((Label)e.Item.FindControl("lbl_cc")).Text = dr["num_cc"].ToString();

                ((Label)e.Item.FindControl("lbl_perfil")).Text = dr["id_perfil"].ToString();

                ((Label)e.Item.FindControl("lbl_ativa")).Text = dr["ativa"].ToString();


                ((LinkButton)e.Item.FindControl("btn_ok")).CommandArgument = dr["id_utilizador"].ToString();




            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("inserircliente.aspx");
        }
    }
}