﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Apostugal
{
    public partial class gerefundos : System.Web.UI.Page
    {
        SqlConnection myConn;

        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["Cliente"] == null)
            {
                Response.Redirect("login.aspx");
            }
        }

        protected void btn_depositar_Click(object sender, EventArgs e)
        {
            try
            {

                myConn = new SqlConnection(ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);

                SqlCommand myCommand = new SqlCommand();

                myCommand.Parameters.AddWithValue("@id", Session["id"]);
                myCommand.Parameters.AddWithValue("@quantia", tb_depositar.Text);




                myCommand.CommandType = CommandType.StoredProcedure;

                myCommand.CommandText = "depositar";

                SqlParameter valor = new SqlParameter();
                valor.ParameterName = "@retorno";

                valor.Direction = ParameterDirection.Output;
                valor.SqlDbType = SqlDbType.Int;
                valor.Size = 1;

                myCommand.Parameters.Add(valor);






                myCommand.Connection = myConn;


                myConn.Open();

                myCommand.ExecuteNonQuery();




                int resposta = Convert.ToInt32(myCommand.Parameters["@retorno"].Value);



                if (resposta == 1)
                {
                    lbl_depositar.Text = "Depósito executado com sucesso! \nPode continuar a apostar!";
                }

                else if (resposta == 2)
                {
                    lbl_depositar.Text = "Depósito executado com sucesso! \nPode começar a apostar!";
                }
                else if (resposta == 3)
                {
                    lbl_depositar.Text = "Depósito executado com sucesso! \nPode começar a apostar!";

                }
                else if (resposta == 4)
                {
                    lbl_depositar.Text = "Depósito executado com sucesso! \nPode começar a apostar!";
                }
                else
                {
                    lbl_depositar.Text = "Falha ao inserir depósito";
                }
            }

            catch (Exception ex)

            {
                Response.Write(ex.Message);
            }

            finally
            {
                myConn.Close();
            }
            Response.Redirect("gerefundos.aspx");
        }

        protected void btn_levantar_Click(object sender, EventArgs e)
        {
            try
            {

                myConn = new SqlConnection(ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);

                SqlCommand myCommand = new SqlCommand();

                myCommand.Parameters.AddWithValue("@id", Session["id"]);
                myCommand.Parameters.AddWithValue("@quantia", tb_levantar.Text);




                myCommand.CommandType = CommandType.StoredProcedure;

                myCommand.CommandText = "levantar";

                SqlParameter valor = new SqlParameter();
                valor.ParameterName = "@retorno";

                valor.Direction = ParameterDirection.Output;
                valor.SqlDbType = SqlDbType.Int;
                valor.Size = 1;

                myCommand.Parameters.Add(valor);






                myCommand.Connection = myConn;


                myConn.Open();

                myCommand.ExecuteNonQuery();




                int resposta = Convert.ToInt32(myCommand.Parameters["@retorno"].Value);



                if (resposta == 1)
                {
                    lbl_levantar.Text = "Leventamento efetuado com sucesso!";
                }

                else if (resposta == 2)
                {
                    lbl_levantar.Text = "Valor demasiado elevado... Tente um valor mais baixo.";
                }
                else
                {
                    lbl_levantar.Text = "Impossível levantar fundos.";

                }
               
            }

            catch (Exception ex)

            {
                Response.Write(ex.Message);
            }

            finally
            {
                myConn.Close();
            }
            Response.Redirect("gerefundos.aspx");
        }

        protected void btn_levantar_tudo_Click(object sender, EventArgs e)
        {
            try
            {

                myConn = new SqlConnection(ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);

                SqlCommand myCommand = new SqlCommand();

                myCommand.Parameters.AddWithValue("@id", Session["id"]);
                




                myCommand.CommandType = CommandType.StoredProcedure;

                myCommand.CommandText = "levantar_tudo";

                SqlParameter valor = new SqlParameter();
                valor.ParameterName = "@retorno";

                valor.Direction = ParameterDirection.Output;
                valor.SqlDbType = SqlDbType.Int;
                valor.Size = 1;

                myCommand.Parameters.Add(valor);






                myCommand.Connection = myConn;


                myConn.Open();

                myCommand.ExecuteNonQuery();




                int resposta = Convert.ToInt32(myCommand.Parameters["@retorno"].Value);



                if (resposta == 1)
                {
                    lbl_depositar.Text = "Leventamento efetuado com sucesso!";
                }

               
                else
                {
                    lbl_depositar.Text = "Impossível levantar fundos.";

                }

            }

            catch (Exception ex)

            {
                Response.Write(ex.Message);
            }

            finally
            {
                myConn.Close();
            }
            
            Response.Redirect("gerefundos.aspx");
        }
    }
}