﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Apostugal
{
    public partial class apostar : System.Web.UI.Page
    {
        SqlConnection myConn;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Cliente"] == null)
            {
                Response.Redirect("login.aspx");
            }

            if (!Page.IsPostBack)
            {
                myConn = new SqlConnection(ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);


                myConn.Open();

                string query1 = "select * from jogos where id_jogo=" + Request.QueryString["jogo"];

                //string getforca_casa = $"SELECT equipas.forca_casa FROM equipas INNER JOIN jogos ON equipas.id_equipa = jogos.id_equipa_casa WHERE jogos.id_jogo =";

                //string getforca_fora = $"SELECT equipas.forca_fora FROM equipas INNER JOIN jogos ON equipas.id_equipa = jogos.id_equipa_fora  WHERE jogos.id_jogo =";

                //SqlDataSource1.SelectCommand = SqlDataSource1 + Session["id_jogo"].ToString();
                //SqlDataSource2.SelectCommand = SqlDataSource2 + Request.QueryString["jogo"];

                //int forca_casa = Convert.ToInt32(SqlDataSource1.ToString());
                //int forca_fora = Convert.ToInt32(SqlDataSource2.ToString());




                string query = "SELECT equipas.nome as 'Equipa Casa', equipas.forca_casa as 'Forca Casa', equipas_1.nome AS 'Equipa Visitante', equipas_1.forca_fora AS 'Forca Fora', equipas.id_equipa as 'id_casa', equipas_1.id_equipa as 'id_fora' FROM equipas INNER JOIN  jogos ON equipas.id_equipa = jogos.id_equipa_casa INNER JOIN equipas AS equipas_1 ON jogos.id_equipa_fora = equipas_1.id_equipa Where jogos.id_jogo =" + Request.QueryString["jogo"];





                SqlCommand myCommand = new SqlCommand(query, myConn);

                SqlDataReader reader = myCommand.ExecuteReader();
                while (reader.Read())
                {
                    lbl_casa.Text = reader["Equipa Casa"].ToString();
                    lbl_fora.Text = reader["Equipa Visitante"].ToString();
                    double forca_casa = Convert.ToInt32(reader["Forca Casa"]);
                    double forca_fora = Convert.ToInt32(reader["Forca Fora"]);
                    lbl_titulo_casa.Text = reader["Equipa Casa"].ToString();
                    lbl_titulo_fora.Text = reader["Equipa Visitante"].ToString();
                    lbl_id_casa.Text = reader["id_casa"].ToString();
                    lbl_id_fora.Text = reader["id_fora"].ToString();


                    if (forca_casa > 80 && forca_fora > 80) //Jogos grandes
                    {
                        double odd_casa = Math.Round(((forca_fora / forca_casa) * 2.5), 2);
                        double odd_fora = Math.Round(((forca_casa / forca_fora) * 2.5), 2);
                        double odd_empate = Math.Round(((odd_casa + odd_fora) / 1.5), 2);
                        lbl_odd_casa.Text = odd_casa.ToString();
                        lbl_odd_empate.Text = odd_empate.ToString();
                        lbl_odd_fora.Text = odd_fora.ToString();
                    }

                    else if (forca_fora > 80 && forca_casa < 80) //Jogos com grandes visitantes
                    {
                        double odd_casa = Math.Round(((forca_fora / forca_casa) * 2), 2);
                        double odd_fora = Math.Round(((forca_casa / forca_fora) * 2.5), 2);
                        double odd_empate = Math.Round(((odd_casa + odd_fora) / 1.5), 2);
                        lbl_odd_casa.Text = odd_casa.ToString();
                        lbl_odd_empate.Text = odd_empate.ToString();
                        lbl_odd_fora.Text = odd_fora.ToString();
                    }
                    else //todos os outros jogos
                    {
                        double odd_casa = Math.Round(((forca_fora / forca_casa) * 2), 2);
                        double odd_fora = Math.Round(((forca_casa / forca_fora) * 3), 2);
                        double odd_empate = Math.Round(((odd_casa + odd_fora) / 1.5), 2);
                        lbl_odd_casa.Text = odd_casa.ToString();
                        lbl_odd_empate.Text = odd_empate.ToString();
                        lbl_odd_fora.Text = odd_fora.ToString();
                    }

                    //lbl_odd_casa.Text = odd_casa.ToString();
                    //lbl_odd_empate.Text = odd_empate.ToString();
                    //lbl_odd_fora.Text = odd_fora.ToString();

                }






                //lbl_odd_casa.Text = odd_casa.ToString();
                //lbl_odd_empate.Text = odd_empate.ToString();
                //lbl_odd_fora.Text = odd_fora.ToString();

                myConn.Close();

            }
        }

        protected void btn_vitoria_Click(object sender, EventArgs e)
        {



            try
            {

                myConn = new SqlConnection(ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);

                SqlCommand myCommand = new SqlCommand();

                myCommand.Parameters.AddWithValue("@id", Session["id"].ToString());
                myCommand.Parameters.AddWithValue("@id_jogo", Request.QueryString["jogo"].ToString());
                myCommand.Parameters.AddWithValue("@odd", lbl_odd_casa.Text);
                myCommand.Parameters.AddWithValue("@valor", ddl_valor.SelectedItem.ToString());




                myCommand.CommandType = CommandType.StoredProcedure;


                myCommand.CommandText = "betVitoria";

                SqlParameter valor = new SqlParameter();
                valor.ParameterName = "@retorno";

                valor.Direction = ParameterDirection.Output;
                valor.SqlDbType = SqlDbType.Int;
                valor.Size = 1;

                myCommand.Parameters.Add(valor);
                myCommand.Connection = myConn;


                myConn.Open();

                myCommand.ExecuteNonQuery();




                int resposta = Convert.ToInt32(myCommand.Parameters["@retorno"].Value);

                if (resposta == 1)
                {
                    lbl_message.Text = "Aposta realizada, boa sorte!";
                }

                else if (resposta == 2)
                {
                    lbl_message.Text = "Impossível realizar a aposta por não ter fundos necessários\nConsidere outro valor ou deposite fundos.";

                }
                else if(resposta == 3)
                {
                    lbl_message.Text = "Aposta Duplicada";
                }
                else
                {
                    lbl_message.Text = "Aposta duplicada";
                }
            }

            catch (Exception ex)

            {
                Response.Write(ex.Message);
            }

            finally
            {
                myConn.Close();
            }
        }

        protected void btn_empate_Click(object sender, EventArgs e)
        {
            try
            {
                myConn = new SqlConnection(ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);

                SqlCommand myCommand = new SqlCommand();

                myCommand.Parameters.AddWithValue("@id", Session["id"].ToString());
                myCommand.Parameters.AddWithValue("@id_jogo", Request.QueryString["jogo"].ToString());
                myCommand.Parameters.AddWithValue("@odd", lbl_odd_empate.Text);
                myCommand.Parameters.AddWithValue("@valor", ddl_valor.SelectedItem.ToString());




                myCommand.CommandType = CommandType.StoredProcedure;


                myCommand.CommandText = "betEmpate";

                SqlParameter valor = new SqlParameter();
                valor.ParameterName = "@retorno";

                valor.Direction = ParameterDirection.Output;
                valor.SqlDbType = SqlDbType.Int;
                valor.Size = 1;

                myCommand.Parameters.Add(valor);
                myCommand.Connection = myConn;


                myConn.Open();

                myCommand.ExecuteNonQuery();




                int resposta = Convert.ToInt32(myCommand.Parameters["@retorno"].Value);

                if (resposta == 1)
                {
                    lbl_message.Text = "Aposta realizada, boa sorte!";
                }

                else if (resposta == 2)
                {
                    lbl_message.Text = "Impossível realizar a aposta por não ter fundos necessários\nConsidere outro valor ou deposite fundos.";

                }
                else if (resposta == 3)
                {
                    lbl_message.Text = "Aposta Duplicada";
                }
                else
                {
                    lbl_message.Text = "Aposta duplicada";
                }
            }

            catch (Exception ex)

            {
                Response.Write(ex.Message);
            }

            finally
            {
                myConn.Close();
            }
        }

        protected void btn_derrota_Click(object sender, EventArgs e)
        {
            try
            {
                myConn = new SqlConnection(ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);

                SqlCommand myCommand = new SqlCommand();

                myCommand.Parameters.AddWithValue("@id", Session["id"].ToString());
                myCommand.Parameters.AddWithValue("@id_jogo", Request.QueryString["jogo"].ToString());
                myCommand.Parameters.AddWithValue("@odd", lbl_odd_fora.Text);
                myCommand.Parameters.AddWithValue("@valor", ddl_valor.SelectedItem.ToString());




                myCommand.CommandType = CommandType.StoredProcedure;


                myCommand.CommandText = "betDerrota";

                SqlParameter valor = new SqlParameter();
                valor.ParameterName = "@retorno";

                valor.Direction = ParameterDirection.Output;
                valor.SqlDbType = SqlDbType.Int;
                valor.Size = 1;

                myCommand.Parameters.Add(valor);
                myCommand.Connection = myConn;


                myConn.Open();

                myCommand.ExecuteNonQuery();




                int resposta = Convert.ToInt32(myCommand.Parameters["@retorno"].Value);

                if (resposta == 1)
                {
                    lbl_message.Text = "Aposta realizada, boa sorte!";
                }

                else if (resposta == 2)
                {
                    lbl_message.Text = "Impossível realizar a aposta por não ter fundos necessários\nConsidere outro valor ou deposite fundos.";

                }
                else if (resposta == 3)
                {
                    lbl_message.Text = "Aposta Duplicada";
                }
                else
                {
                    lbl_message.Text = "Aposta duplicada";
                }
            }

            catch (Exception ex)

            {
                Response.Write(ex.Message);
            }

            finally
            {
                myConn.Close();
            }
        }

        protected void btn_golos_menos_Click(object sender, EventArgs e)
        {
            try
            {
                myConn = new SqlConnection(ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);

                SqlCommand myCommand = new SqlCommand();

                myCommand.Parameters.AddWithValue("@id", Session["id"].ToString());
                myCommand.Parameters.AddWithValue("@id_jogo", Request.QueryString["jogo"].ToString());
                myCommand.Parameters.AddWithValue("@odd", lbl_odd_golos_menos.Text);
                myCommand.Parameters.AddWithValue("@valor", ddl_valor.SelectedItem.ToString());




                myCommand.CommandType = CommandType.StoredProcedure;


                myCommand.CommandText = "betGolosMenos";

                SqlParameter valor = new SqlParameter();
                valor.ParameterName = "@retorno";

                valor.Direction = ParameterDirection.Output;
                valor.SqlDbType = SqlDbType.Int;
                valor.Size = 1;

                myCommand.Parameters.Add(valor);
                myCommand.Connection = myConn;


                myConn.Open();

                myCommand.ExecuteNonQuery();




                int resposta = Convert.ToInt32(myCommand.Parameters["@retorno"].Value);

                if (resposta == 1)
                {
                    lbl_message.Text = "Aposta realizada, boa sorte!";
                }

                else if (resposta == 2)
                {
                    lbl_message.Text = "Impossível realizar a aposta por não ter fundos necessários\nConsidere outro valor ou deposite fundos.";

                }
                else if (resposta == 3)
                {
                    lbl_message.Text = "Aposta Duplicada";
                }
                else
                {
                    lbl_message.Text = "Aposta duplicada";
                }
            }

            catch (Exception ex)

            {
                Response.Write(ex.Message);
            }

            finally
            {
                myConn.Close();
            }
        }

        protected void btn_golos_mais_Click(object sender, EventArgs e)
        {
            try
            {
                myConn = new SqlConnection(ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);

                SqlCommand myCommand = new SqlCommand();

                myCommand.Parameters.AddWithValue("@id", Session["id"].ToString());
                myCommand.Parameters.AddWithValue("@id_jogo", Request.QueryString["jogo"].ToString());
                myCommand.Parameters.AddWithValue("@odd", lbl_odd_golos_mais.Text);
                myCommand.Parameters.AddWithValue("@valor", ddl_valor.SelectedItem.ToString());




                myCommand.CommandType = CommandType.StoredProcedure;


                myCommand.CommandText = "betGolosMais";

                SqlParameter valor = new SqlParameter();
                valor.ParameterName = "@retorno";

                valor.Direction = ParameterDirection.Output;
                valor.SqlDbType = SqlDbType.Int;
                valor.Size = 1;

                myCommand.Parameters.Add(valor);
                myCommand.Connection = myConn;


                myConn.Open();

                myCommand.ExecuteNonQuery();




                int resposta = Convert.ToInt32(myCommand.Parameters["@retorno"].Value);

                if (resposta == 1)
                {
                    lbl_message.Text = "Aposta realizada, boa sorte!";
                }

                else if (resposta == 2)
                {
                    lbl_message.Text = "Impossível realizar a aposta por não ter fundos necessários\nConsidere outro valor ou deposite fundos.";

                }
                else if (resposta == 3)
                {
                    lbl_message.Text = "Aposta Duplicada";
                }
                else
                {
                    lbl_message.Text = "Aposta duplicada";
                }
            }

            catch (Exception ex)

            {
                Response.Write(ex.Message);
            }

            finally
            {
                myConn.Close();
            }
        }

        protected void btn_cantos_menos_Click(object sender, EventArgs e)
        {
            try
            {
                myConn = new SqlConnection(ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);

                SqlCommand myCommand = new SqlCommand();

                myCommand.Parameters.AddWithValue("@id", Session["id"].ToString());
                myCommand.Parameters.AddWithValue("@id_jogo", Request.QueryString["jogo"].ToString());
                myCommand.Parameters.AddWithValue("@odd", lbl_odd_cantos_menos.Text);
                myCommand.Parameters.AddWithValue("@valor", ddl_valor.SelectedItem.ToString());




                myCommand.CommandType = CommandType.StoredProcedure;


                myCommand.CommandText = "betCantosMenos";

                SqlParameter valor = new SqlParameter();
                valor.ParameterName = "@retorno";

                valor.Direction = ParameterDirection.Output;
                valor.SqlDbType = SqlDbType.Int;
                valor.Size = 1;

                myCommand.Parameters.Add(valor);
                myCommand.Connection = myConn;


                myConn.Open();

                myCommand.ExecuteNonQuery();




                int resposta = Convert.ToInt32(myCommand.Parameters["@retorno"].Value);

                if (resposta == 1)
                {
                    lbl_message.Text = "Aposta realizada, boa sorte!";
                }

                else if (resposta == 2)
                {
                    lbl_message.Text = "Impossível realizar a aposta por não ter fundos necessários\nConsidere outro valor ou deposite fundos.";

                }
                else
                {
                    lbl_message.Text = "Aposta duplicada";
                }
            }

            catch (Exception ex)

            {
                Response.Write(ex.Message);
            }

            finally
            {
                myConn.Close();
            }
        }

        protected void btn_cantos_mais_Click(object sender, EventArgs e)
        {
            try
            {
                myConn = new SqlConnection(ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);

                SqlCommand myCommand = new SqlCommand();

                myCommand.Parameters.AddWithValue("@id", Session["id"].ToString());
                myCommand.Parameters.AddWithValue("@id_jogo", Request.QueryString["jogo"].ToString());
                myCommand.Parameters.AddWithValue("@odd", lbl_odd_cantos_mais.Text);
                myCommand.Parameters.AddWithValue("@valor", ddl_valor.SelectedItem.ToString());




                myCommand.CommandType = CommandType.StoredProcedure;


                myCommand.CommandText = "betCantosMais";

                SqlParameter valor = new SqlParameter();
                valor.ParameterName = "@retorno";

                valor.Direction = ParameterDirection.Output;
                valor.SqlDbType = SqlDbType.Int;
                valor.Size = 1;

                myCommand.Parameters.Add(valor);
                myCommand.Connection = myConn;


                myConn.Open();

                myCommand.ExecuteNonQuery();




                int resposta = Convert.ToInt32(myCommand.Parameters["@retorno"].Value);

                if (resposta == 1)
                {
                    lbl_message.Text = "Aposta realizada, boa sorte!";
                }

                else if (resposta == 2)
                {
                    lbl_message.Text = "Impossível realizar a aposta por não ter fundos necessários\nConsidere outro valor ou deposite fundos.";

                }
                else if (resposta == 3)
                {
                    lbl_message.Text = "Aposta Duplicada";
                }
                else
                {
                    lbl_message.Text = "Aposta duplicada";
                }
            }

            catch (Exception ex)

            {
                Response.Write(ex.Message);
            }

            finally
            {
                myConn.Close();
            }
        }

        protected void btn_ca_menos_Click(object sender, EventArgs e)
        {
            try
            {
                myConn = new SqlConnection(ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);

                SqlCommand myCommand = new SqlCommand();

                myCommand.Parameters.AddWithValue("@id", Session["id"].ToString());
                myCommand.Parameters.AddWithValue("@id_jogo", Request.QueryString["jogo"].ToString());
                myCommand.Parameters.AddWithValue("@odd", lbl_odd_ca_menos.Text);
                myCommand.Parameters.AddWithValue("@valor", ddl_valor.SelectedItem.ToString());




                myCommand.CommandType = CommandType.StoredProcedure;


                myCommand.CommandText = "betCAMenos";

                SqlParameter valor = new SqlParameter();
                valor.ParameterName = "@retorno";

                valor.Direction = ParameterDirection.Output;
                valor.SqlDbType = SqlDbType.Int;
                valor.Size = 1;

                myCommand.Parameters.Add(valor);
                myCommand.Connection = myConn;


                myConn.Open();

                myCommand.ExecuteNonQuery();




                int resposta = Convert.ToInt32(myCommand.Parameters["@retorno"].Value);

                if (resposta == 1)
                {
                    lbl_message.Text = "Aposta realizada, boa sorte!";
                }

                else if (resposta == 2)
                {
                    lbl_message.Text = "Impossível realizar a aposta por não ter fundos necessários\nConsidere outro valor ou deposite fundos.";

                }
                else if (resposta == 3)
                {
                    lbl_message.Text = "Aposta Duplicada";
                }
                else
                {
                    lbl_message.Text = "Aposta duplicada";
                }
            }

            catch (Exception ex)

            {
                Response.Write(ex.Message);
            }

            finally
            {
                myConn.Close();
            }
        }

        protected void btn_ca_mais_Click(object sender, EventArgs e)
        {
            try
            {
                myConn = new SqlConnection(ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);

                SqlCommand myCommand = new SqlCommand();

                myCommand.Parameters.AddWithValue("@id", Session["id"].ToString());
                myCommand.Parameters.AddWithValue("@id_jogo", Request.QueryString["jogo"].ToString());
                myCommand.Parameters.AddWithValue("@odd", lbl_odd_ca_mais.Text);
                myCommand.Parameters.AddWithValue("@valor", ddl_valor.SelectedItem.ToString());




                myCommand.CommandType = CommandType.StoredProcedure;


                myCommand.CommandText = "betCAMais";

                SqlParameter valor = new SqlParameter();
                valor.ParameterName = "@retorno";

                valor.Direction = ParameterDirection.Output;
                valor.SqlDbType = SqlDbType.Int;
                valor.Size = 1;

                myCommand.Parameters.Add(valor);
                myCommand.Connection = myConn;


                myConn.Open();

                myCommand.ExecuteNonQuery();




                int resposta = Convert.ToInt32(myCommand.Parameters["@retorno"].Value);

                if (resposta == 1)
                {
                    lbl_message.Text = "Aposta realizada, boa sorte!";
                }

                else if (resposta == 2)
                {
                    lbl_message.Text = "Impossível realizar a aposta por não ter fundos necessários\nConsidere outro valor ou deposite fundos.";

                }
                else if (resposta == 3)
                {
                    lbl_message.Text = "Aposta Duplicada";
                }
                else
                {
                    lbl_message.Text = "Aposta duplicada";
                }
            }

            catch (Exception ex)

            {
                Response.Write(ex.Message);
            }

            finally
            {
                myConn.Close();
            }
        }

        protected void btn_cv_menos_Click(object sender, EventArgs e)
        {
            try
            {
                myConn = new SqlConnection(ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);

                SqlCommand myCommand = new SqlCommand();

                myCommand.Parameters.AddWithValue("@id", Session["id"].ToString());
                myCommand.Parameters.AddWithValue("@id_jogo", Request.QueryString["jogo"].ToString());
                myCommand.Parameters.AddWithValue("@odd", lbl_odd_cv_menos.Text);
                myCommand.Parameters.AddWithValue("@valor", ddl_valor.SelectedItem.ToString());




                myCommand.CommandType = CommandType.StoredProcedure;


                myCommand.CommandText = "betCVMenos";

                SqlParameter valor = new SqlParameter();
                valor.ParameterName = "@retorno";

                valor.Direction = ParameterDirection.Output;
                valor.SqlDbType = SqlDbType.Int;
                valor.Size = 1;

                myCommand.Parameters.Add(valor);
                myCommand.Connection = myConn;


                myConn.Open();

                myCommand.ExecuteNonQuery();




                int resposta = Convert.ToInt32(myCommand.Parameters["@retorno"].Value);

                if (resposta == 1)
                {
                    lbl_message.Text = "Aposta realizada, boa sorte!";
                }

                else if (resposta == 2)
                {
                    lbl_message.Text = "Impossível realizar a aposta por não ter fundos necessários\nConsidere outro valor ou deposite fundos.";

                }
                else if (resposta == 3)
                {
                    lbl_message.Text = "Aposta Duplicada";
                }
                else
                {
                    lbl_message.Text = "Aposta duplicada";
                }
            }

            catch (Exception ex)

            {
                Response.Write(ex.Message);
            }

            finally
            {
                myConn.Close();
            }
        }

        protected void btn_cv_mais_Click(object sender, EventArgs e)
        {
            try
            {
                myConn = new SqlConnection(ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);

                SqlCommand myCommand = new SqlCommand();

                myCommand.Parameters.AddWithValue("@id", Session["id"].ToString());
                myCommand.Parameters.AddWithValue("@id_jogo", Request.QueryString["jogo"].ToString());
                myCommand.Parameters.AddWithValue("@odd", lbl_odd_cv_mais.Text);
                myCommand.Parameters.AddWithValue("@valor", ddl_valor.SelectedItem.ToString());




                myCommand.CommandType = CommandType.StoredProcedure;


                myCommand.CommandText = "betCVMais";

                SqlParameter valor = new SqlParameter();
                valor.ParameterName = "@retorno";

                valor.Direction = ParameterDirection.Output;
                valor.SqlDbType = SqlDbType.Int;
                valor.Size = 1;

                myCommand.Parameters.Add(valor);
                myCommand.Connection = myConn;


                myConn.Open();

                myCommand.ExecuteNonQuery();




                int resposta = Convert.ToInt32(myCommand.Parameters["@retorno"].Value);

                if (resposta == 1)
                {
                    lbl_message.Text = "Aposta realizada, boa sorte!";
                }

                else if (resposta == 2)
                {
                    lbl_message.Text = "Impossível realizar a aposta por não ter fundos necessários\nConsidere outro valor ou deposite fundos.";

                }
                else if (resposta == 3)
                {
                    lbl_message.Text = "Aposta Duplicada";
                }
                else
                {
                    lbl_message.Text = "Aposta duplicada";
                }
            }

            catch (Exception ex)

            {
                Response.Write(ex.Message);
            }

            finally
            {
                myConn.Close();
            }
        }
    }
}