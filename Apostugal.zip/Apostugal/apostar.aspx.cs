﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Apostugal
{
    public partial class apostar : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Cliente"] == null)
            {
                Response.Redirect("login.aspx");
            }

            if (!Page.IsPostBack)
            {
                SqlConnection myConn = new SqlConnection(ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);
                

                myConn.Open();
                
                string query1 = "select * from jogos where id_jogo=" + Request.QueryString["jogo"];

                //string getforca_casa = $"SELECT equipas.forca_casa FROM equipas INNER JOIN jogos ON equipas.id_equipa = jogos.id_equipa_casa WHERE jogos.id_jogo =";

                //string getforca_fora = $"SELECT equipas.forca_fora FROM equipas INNER JOIN jogos ON equipas.id_equipa = jogos.id_equipa_fora  WHERE jogos.id_jogo =";

                //SqlDataSource1.SelectCommand = SqlDataSource1 + Session["id_jogo"].ToString();
                //SqlDataSource2.SelectCommand = SqlDataSource2 + Request.QueryString["jogo"];

                //int forca_casa = Convert.ToInt32(SqlDataSource1.ToString());
                //int forca_fora = Convert.ToInt32(SqlDataSource2.ToString());

              


                string query = "SELECT equipas.nome as 'Equipa Casa', equipas.forca_casa as 'Forca Casa', equipas_1.nome AS 'Equipa Visitante', equipas_1.forca_fora AS 'Forca Fora'  FROM equipas INNER JOIN  jogos ON equipas.id_equipa = jogos.id_equipa_casa INNER JOIN equipas AS equipas_1 ON jogos.id_equipa_fora = equipas_1.id_equipa Where jogos.id_jogo =" + Request.QueryString["jogo"];


                


                SqlCommand myCommand = new SqlCommand(query,  myConn);

                SqlDataReader reader = myCommand.ExecuteReader();
                while (reader.Read())
                {
                    lbl_casa.Text = reader["Equipa Casa"].ToString();
                    lbl_fora.Text = reader["Equipa Visitante"].ToString();
                    lbl_casa_golos.Text = reader["Equipa Casa"].ToString();
                    lbl_fora_golos.Text = reader["Equipa Visitante"].ToString();
                    lbl_cantos_casa.Text = reader["Equipa Casa"].ToString();
                    lbl_cantos_fora.Text = reader["Equipa Visitante"].ToString();
                    lbl_ca_casa.Text = reader["Equipa Casa"].ToString();
                    lbl_ca_fora.Text = reader["Equipa Visitante"].ToString();
                    lbl_cv_casa.Text = reader["Equipa Casa"].ToString();
                    lbl_cv_fora.Text = reader["Equipa Visitante"].ToString();
                    double forca_casa = Convert.ToInt32(reader["Forca Casa"]);
                    double forca_fora = Convert.ToInt32(reader["Forca Fora"]);

                    
                    if(forca_casa >80 && forca_fora > 80) //Jogos grandes
                    {
                        double odd_casa = Math.Round(((forca_fora / forca_casa) * 2.5), 2);
                        double odd_fora = Math.Round(((forca_casa / forca_fora) * 2.5), 2);
                        double odd_empate = Math.Round(((odd_casa + odd_fora) / 1.5), 2);
                        lbl_odd_casa.Text = odd_casa.ToString();
                        lbl_odd_empate.Text = odd_empate.ToString();
                        lbl_odd_fora.Text = odd_fora.ToString();
                    }

                   else if (forca_fora > 80 && forca_casa < 80) //Jogos com grandes visitantes
                    {
                        double odd_casa = Math.Round(((forca_fora / forca_casa) * 2), 2);
                        double odd_fora = Math.Round(((forca_casa / forca_fora) * 2.5), 2);
                        double odd_empate = Math.Round(((odd_casa + odd_fora) / 1.5), 2);
                        lbl_odd_casa.Text = odd_casa.ToString();
                        lbl_odd_empate.Text = odd_empate.ToString();
                        lbl_odd_fora.Text = odd_fora.ToString();
                    }
                    else //todos os outros jogos
                    {
                        double odd_casa = Math.Round(((forca_fora / forca_casa) * 2), 2);
                        double odd_fora = Math.Round(((forca_casa / forca_fora) * 3), 2);
                        double odd_empate = Math.Round(((odd_casa + odd_fora) / 1.5), 2);
                        lbl_odd_casa.Text = odd_casa.ToString();
                        lbl_odd_empate.Text = odd_empate.ToString();
                        lbl_odd_fora.Text = odd_fora.ToString();
                    }

                    //lbl_odd_casa.Text = odd_casa.ToString();
                    //lbl_odd_empate.Text = odd_empate.ToString();
                    //lbl_odd_fora.Text = odd_fora.ToString();

                }

                

                


                //lbl_odd_casa.Text = odd_casa.ToString();
                //lbl_odd_empate.Text = odd_empate.ToString();
                //lbl_odd_fora.Text = odd_fora.ToString();

                myConn.Close();

            }
        }

        protected void btn_vitoria_Click(object sender, EventArgs e)
        {

        }

        protected void btn_empate_Click(object sender, EventArgs e)
        {

        }

        protected void btn_derrota_Click(object sender, EventArgs e)
        {

        }
    }
}