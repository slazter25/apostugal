﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace Apostugal
{
    public partial class gestaodeprodutos : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null)
            {
                Response.Redirect("login.aspx");
            }
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            SqlConnection myConn = new SqlConnection(ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);

            if (e.CommandName.Equals("btn_okay"))
            {
                Response.Redirect("editar_produto.aspx?cod_produto=" + ((Label)e.Item.FindControl("lbl_idproduto")).Text);
            }

            

            if (e.CommandName.Equals("btn_apagar"))
            {

                string query = "Delete from produtos where cod_produto=" + ((LinkButton)e.Item.FindControl("btn_apaga")).CommandArgument;
                SqlCommand myCommand = new SqlCommand(query, myConn);
                myCommand.ExecuteNonQuery();

            }
        }

        protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                DataRowView dr = (DataRowView)e.Item.DataItem;
                ((Label)e.Item.FindControl("lbl_idproduto")).Text = dr["cod_produto"].ToString();


                ((Label)e.Item.FindControl("lbl_produto")).Text = dr["designacao"].ToString();


                ((Label)e.Item.FindControl("lbl_pvp")).Text = dr["pvp"].ToString();


                ((Label)e.Item.FindControl("lbl_stock")).Text = dr["stock"].ToString();

                

                ((LinkButton)e.Item.FindControl("btn_okay")).CommandArgument = dr["cod_produto"].ToString();




            }
        }

        protected void btn_inserir_Click(object sender, EventArgs e)
        {
            Response.Redirect("inserir_produto.aspx");
        }
    }
}