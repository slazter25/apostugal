﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Apostugal
{
    public partial class ClienteMaster : System.Web.UI.MasterPage
    {
        SqlConnection myConn;

        protected void Page_Load(object sender, EventArgs e)
        {
            myConn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);

            SqlCommand myCommand = new SqlCommand();

            myCommand.Parameters.AddWithValue("@username", Session["Cliente"].ToString());
        




            myCommand.CommandType = CommandType.StoredProcedure;

            myCommand.CommandText = "getSaldo";

            SqlParameter valor = new SqlParameter();
            valor.ParameterName = "@retorno";

            valor.Direction = ParameterDirection.Output;
            valor.SqlDbType = SqlDbType.Float;
            valor.Size = 1;

            myCommand.Parameters.Add(valor);

            myCommand.Connection = myConn;


            myConn.Open();

            myCommand.ExecuteNonQuery();




            decimal resposta = Convert.ToDecimal(myCommand.Parameters["@retorno"].Value);



            lbl_user.Text = Session["cliente"].ToString();
            lbl_saldo.Text = resposta.ToString();

        }

        protected void logout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
        }
    }
}