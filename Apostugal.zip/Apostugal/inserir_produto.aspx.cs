﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Apostugal
{
    public partial class inserir_produto : System.Web.UI.Page
    {
        SqlConnection myConn;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null)
            {
                Response.Redirect("login.aspx");
            }
        }

        protected void btn_submeter_Click(object sender, EventArgs e)
        {
            try
            {

                myConn = new SqlConnection(ConfigurationManager.ConnectionStrings["apostugalConnectionString"].ConnectionString);

                SqlCommand myCommand = new SqlCommand();

                myCommand.Parameters.AddWithValue("@nome", tb_nome.Text);
                myCommand.Parameters.AddWithValue("@pvp", tb_euros.Text + "." + tb_cents.Text);
                myCommand.Parameters.AddWithValue("@stock", tb_stock.Text);
              


                myCommand.CommandType = CommandType.StoredProcedure;


                myCommand.CommandText = "insere_produto";

                SqlParameter valor = new SqlParameter();
                valor.ParameterName = "@retorno";

                valor.Direction = ParameterDirection.Output;
                valor.SqlDbType = SqlDbType.Int;
                valor.Size = 1;

                myCommand.Parameters.Add(valor);
                myCommand.Connection = myConn;


                myConn.Open();

                myCommand.ExecuteNonQuery();




                int resposta = Convert.ToInt32(myCommand.Parameters["@retorno"].Value);

                if (resposta == 1)
                {
                    Response.Write("Produto já existe");
                }
               
                else
                {
                    Response.Write("Produto inserido");
                }
            }

            catch (Exception ex)

            {
                Response.Write(ex.Message);
            }

            finally
            {
                myConn.Close();
            }
        }
    }
}